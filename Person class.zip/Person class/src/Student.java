import java.util.ArrayList;

public class Student extends Person
{
    public Student(int id, String name, String email) {
        super(id, name, email);
    }

    ArrayList<GradeInfo> gradelist = new ArrayList<>();
    public void Grade(double avggrade)
    {
        GradeInfo gl = new GradeInfo(8.5);
        gradelist.add(gl);
    }

    public String toString()
    {
        return id + " " + name + " " + email + " " + avgGrade();
    }

    private double avgGrade() {
        double sum = 0;
        for (GradeInfo g : gradelist)
            sum += g.getGrade();

        return sum / gradelist.size();
    }

}
