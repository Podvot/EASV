
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PersonManager
{

    public void main(String[] args)
    {

        public int id;
        public String name;
        public String email;

    public Person(int id, String name, String email)
        {
            this.id = id;
            this.name = name;
            this.email = email;
        }

        int a = 0;
        while(a == 0)
        {
            Scanner Person = new Scanner(System.in);
            System.out.println("Enter id " + "name " + "email");
            String persons = Person.nextLine();
            if (persons.startsWith("Stop")) {
                a = a + 1;
                System.out.println("Shutting down");
                break;

            } else if (!persons.startsWith("Stop")) {
                int id = Person.nextLine();
                String firstName = Person.nextLine();
                String lastName = Person.nextLine();
                String email = Person.nextLine();

                System.out.println("id: " + id + "first name: " + firstName + "last name" + lastName + " email: " + email);
                System.out.println(" ");
            }
        }

    }
}