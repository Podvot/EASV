public class GradeInfo
{

    public double avggrade;

    public GradeInfo(double avggrade)
    {
        this.avggrade = avggrade;
    }

   public String toString()
    {
        return String.valueOf(avggrade);
    }

    public double getGrade() {
        avggrade = 8.5;
        return avggrade;
    }

}
