
import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {

        ArrayList<Person> people = new ArrayList<>();
        people.add(new Person(100, "Hans Nielsen", "hni@easv.dk"));
        people.add(new Person(101, "Niels Hansen", "nha@easv.dk"));
        people.add(new Person(102, "Ib Boesen", "ibo@easv.dk"));
        people.add(new Teacher(202, "Bent H. Pedersen", "bhp@easv.dk", "bhp", "Programming"));
        people.add(new Teacher(203, "Peder H Bentsen", "phb@easv.dk", "phb", "Software Design"));
        people.add(new Student(105,"Bo Ibsen", "bib@eavs.dk"));

        System.out.printf("%s%10s%13s%18s%10s%20s%20s%n", "ID", "NAME", "EMAIL", "INITIALS", "MAIN", "EDUCATION", "AVGGRADE");

        for (Person p : people)
        {
                System.out.printf("%s%n", p.toString());
        }

    }
}