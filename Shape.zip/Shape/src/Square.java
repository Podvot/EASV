/*public class Square extends TwoDimensional {
    private int højde = 6;
    private int bredde = 9;
    private double area;

    public Square(String shapeName, String calculation, double area){
        super(shapeName, calculation);
    }

    public void getArea(){
        area = højde * bredde;
    }
}

 */
