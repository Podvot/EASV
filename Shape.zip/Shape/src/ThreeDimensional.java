public class ThreeDimensional extends Shape {

    private final String calculation = "";



    public ThreeDimensional(String shapeName, String calculation) {
        super(shapeName);
    }

    public String getCalculation()
    {
        return calculation;
    }

    public void getArea(){

    }

    public void getVolume(){

    }
    @Override
    public double shapeArea()
    {
        return 0;
    }
}
