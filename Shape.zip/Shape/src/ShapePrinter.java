public class ShapePrinter
{

    public static void main(String[] args)
    {
        Circle circle = new Circle("Circle", "π * r * r", "Two dimensional",3.0, 7.07);

        System.out.println(" ");
        System.out.println("Testing circle print");
        System.out.println(" ");
        
        Shape[] shapes = new Shape[1];

        shapes[0] = circle;

        for(Shape currentShape : shapes)
        {
            System.out.println(currentShape);
        }

        for (int i = 0; i < shapes.length; i++)
        {
            System.out.printf("Shape %d is a %s%n", i, shapes[i].getClass().getName());
        }

    }

}