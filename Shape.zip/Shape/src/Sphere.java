/*
public class Sphere extends ThreeDimensional
{
    public Sphere()
    {

    }

}

 */