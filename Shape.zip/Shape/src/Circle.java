public class Circle extends TwoDimensional
{
    private double circleArea;
    private double area;

    public Circle(String shapeName, String calculation, String dimension, double circleArea, double area)
    {
        super(shapeName, calculation, dimension);

        if (circleArea < 0.0)
        {
            throw new IllegalArgumentException("Circle area must be >= 0.0");
        }
        this.circleArea = circleArea;
        this.area = area;
    }

    public void setArea(double area)
    {
        if (area < 0.0)
        {
            throw new IllegalArgumentException("Circle area must be >= 0.0");
        }
        this.area = area;
    }

    public void setCircleArea(double circleArea)
    {
        if (circleArea < 0.0)
        {
            throw new IllegalArgumentException("Circle area must be >= 0.0");
        }
        this.circleArea = circleArea;
    }

    public double getCircleArea()
    {
        return circleArea;
    }

    public double getArea()
    {
        return area;
    }

    @Override
    public double shapeArea()
    {
        return getArea() + super.shapeArea();
    }

    @Override
    public String toString()
    {
        return String.format("%s%n%s%s%n%s%f%n", super.toString(), "Diameter of circle: ", getCircleArea(), "Area of circle: ", getArea());
    }

}
