/*public class Tetrahedron extends ThreeDimensional
{
    public Tetrahedron()
    {

    }

}

 */
