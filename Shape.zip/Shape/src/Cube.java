public class Cube extends ThreeDimensional{
    private int højde = 6;
    private int bredde = 9;
    private int længde = 4;
    private double area;
    private double volume;

    public Cube(String shapeName, String calculation, double area, double volume) {
        super(shapeName, calculation);
    }

    public void getArea(){
        area = højde * bredde * 6;
    }

    public void getVolume(){
        volume = højde * bredde * længde;
    }
}
