public class TwoDimensional extends Shape
{

    private final String calculation;
    private final String dimension;

    public TwoDimensional(String shapeName, String calculation, String dimension)
    {
        super(shapeName);

        this.calculation = calculation;
        this.dimension = dimension;
    }


    public String getCalculation()
    {
        return calculation;
    }
    public String getDimension()
    {
        return dimension;
    }

    @Override
    public double shapeArea()
    {
        return 0.0;
    }

    @Override
    public String toString()
    {
        return String.format("Shape name: %s%s%s%n%s%s", super.toString(), "Dimension: ", getDimension(), "Formula: ", getCalculation());
    }

}