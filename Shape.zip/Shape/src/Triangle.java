/*public class Triangle extends TwoDimensional{
    private int højde = 5;
    private int bredde = 10;
    private double area;

    public Triangle(String shapeName, String calculation, double area) {
        super(shapeName, calculation);
    }
    //h*B/2
    public void getArea() {
        area = højde * bredde / 2;

    }
}

 */