module com.example.filmprojekt {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires java.sql;
    requires java.desktop;

    exports com.example.filmprojekt;
    opens com.example.filmprojekt;
    exports com.example.filmprojekt.Model;
    opens com.example.filmprojekt.Model to javafx.fxml;
    exports com.example.filmprojekt.dao;
    opens com.example.filmprojekt.dao to javafx.fxml;


}