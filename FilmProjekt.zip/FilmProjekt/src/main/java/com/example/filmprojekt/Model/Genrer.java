package com.example.filmprojekt.Model;

import java.util.ArrayList;
import java.util.List;

public class Genrer
{
    private int id;
    private String genreName;
    private List<Trailer> trailer = new ArrayList<>();

    public Genrer(int id, String genreName)
    {
        this.id = id;
        this.genreName = genreName;
    }


    // Metode der tilføjer trailer til en liste
    public void addTrailers(Trailer t)
    {
        trailer.add(t);
    }

    public List<Trailer> getTrailer() {
        return trailer;
    }

    public String toString()
    {
        return genreName;
    }

    public int getId() {
        return id;
    }

    public String getListName() {
        return genreName;
    }
}

