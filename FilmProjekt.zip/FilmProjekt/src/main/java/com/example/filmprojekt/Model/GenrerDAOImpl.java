package com.example.filmprojekt.Model;

import com.example.filmprojekt.dao.GenrerDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;

public class GenrerDAOImpl implements GenrerDAO
{
    private Connection con; // forbindelsen til databasen

    public GenrerDAOImpl()
    {
        try
        {
            // Connector til databasen
            con = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-SAUNN72M\\MSSQLSERVER:1433;database=Trailers;userName=sa;password=sa;encrypt=true;trustServerCertificate=true");
        }

        catch (SQLException e)
        {
            System.err.println("Could not create connection  " + e.getMessage());
        }
        System.out.println("Connected");
    }

    // Metode der opretter en genre med navnet en bruger har indtastet
    public void addGenre(String genre)
    {
        try
        {
            PreparedStatement ps = con.prepareStatement("INSERT INTO Genrer VALUES(?);");

            ps.setString(1, genre);

            ps.executeUpdate();
        }
        catch (SQLException e)
        {
            System.err.println("Kan ikke oprette genre " + e.getMessage());
        }
    }

    // Viser alle genrer der i andet lastview til venstre.
    public List<Genrer> getAllGenres()
    {

        List<Genrer> getAllGenrers = new ArrayList();
        try
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Genrer");
            ResultSet rs = ps.executeQuery();

            Genrer genrer;
            while(rs.next())
            {
                int id = rs.getInt(1);
                String genreName = rs.getString(2);

                genrer = new Genrer(id,genreName);
                getAllGenrers.add(genrer);
            }
        }
        catch (SQLException e)
        {
            System.err.println("can not access genre folders" + e.getMessage());
        }
        return getAllGenrers;
    }

    // Sletter den valgte genre mappe.
    @Override
    public void deleteGr(int gr) {
        try
        {
            PreparedStatement ps = con.prepareStatement("DELETE FROM Genrer WHERE genreID = ?;");
            ps.setInt(1,gr);
            ps.executeUpdate();
        }

        catch (SQLException e)
        {
            System.err.println("Kunne ikke slette genre mappe" + e.getMessage());
        }
    }

    //Updaterer navnet på en genre mappe i forhold
    //Til brugerens inputs
    @Override
    public void updateGenre(String genre, int gr) {

        try
        {
            PreparedStatement ps = con.prepareStatement("UPDATE Genrer SET GenreName = ? WHERE genreID = ?;");

            ps.setString(1, genre);
            ps.setInt(2,gr);

            ps.executeUpdate();
        }
        catch (SQLException e)
        {
            System.err.println("Kan ikke ændre genre mappens navn " + e.getMessage());
        }
    }
}
