package com.example.filmprojekt.Model;

import com.example.filmprojekt.dao.PromosDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class PromosDAOImpl implements PromosDAO {
    private Connection con; // forbindelsen til databasen

    public PromosDAOImpl() {
        try {
            // Opretter forbindelse til databasen

            con = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-SAUNN72M\\MSSQLSERVER:1433;database=Trailers;userName=sa;password=sa;encrypt=true;trustServerCertificate=true");
        } catch (SQLException e) {
            System.err.println("can not create connection" + e.getMessage());
        }
        System.out.println("  ");
    }


    // Viser de trailers der er tilknyttet en genre der er valgt.
    @Override
    public List<Trailer> getGenreTrailers(Genrer glist) {

        List<Trailer> promoTrailers = new ArrayList<>();

        try {
            PreparedStatement ps = con.prepareStatement("select * from Trailer, Genrer, Promos where Genrer.genreID = Promos.genreID AND Promos.trailerID = Trailer.trailerID AND Genrer.genreID = ?");
            ps.setInt(1, glist.getId());
            ResultSet rs = ps.executeQuery();
            Trailer trailer;
            while (rs.next()) {
                int id = rs.getInt(1);
                String favourite = rs.getString(2);
                String title = rs.getString(3);
                int personalRating = rs.getInt(4);
                int IMDBrating = rs.getInt(5);
                String genre = rs.getString(6);
                String filelink = rs.getString(7);
                String lastview = rs.getString(8);
                String posterLink = rs.getString(9);
                String information = rs.getString(10);

                trailer = new Trailer(id, favourite, title, personalRating, IMDBrating, genre, filelink, lastview, posterLink, information);
                promoTrailers.add(trailer);
            }
        } catch (SQLException t) {
            System.err.println("Kunne ikke få alle trailers" + t.getMessage());
        }

        return promoTrailers;
    }

    //Sletter en trailer fra den genre mappe
    @Override
    public void deleteGrTrailer(int tl) {
        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM Promos WHERE trailerID = ?;");
            ps.setInt(1, tl);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Kunne ikke slette trailer" + e.getMessage());
        }
    }

    //Tilføjer en trailer fra den valgte genre mappe
    @Override
    public void addTheTrailer(int id1, int id2){
        try {
            PreparedStatement ps = con.prepareStatement("INSERT INTO Promos VALUES (?,?);");
            ps.setInt(1, id1);
            ps.setInt(2, id2);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Kunne ikke tilføje trialer til genre" + e.getMessage());
        }
    }

}
