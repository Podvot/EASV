package com.example.filmprojekt.dao;

import com.example.filmprojekt.Model.Trailer;

import java.util.List;

public interface TrailerDAO
{
    public void addTrailer(String s0, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8); // Create trailer

    public void editTrailer(String s0, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, int id); // Edit trailer

    public List<Trailer> getSearchedTrailer(String query); // Read searched trailer

    public List<Trailer> getAllTrailers(); // Get all trailers

    public void deleteTrailer(int id); // Delete trailer


}
