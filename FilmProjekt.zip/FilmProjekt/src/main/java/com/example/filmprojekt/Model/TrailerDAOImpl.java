package com.example.filmprojekt.Model;

import com.example.filmprojekt.dao.TrailerDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.sql.SQLException;

public class TrailerDAOImpl implements TrailerDAO
{
    private Connection con; // forbindelsen til databasen

    public TrailerDAOImpl(){
        try
        {
            con = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-SAUNN72M\\MSSQLSERVER:1433;database=Trailers;userName=sa;password=sa;encrypt=true;trustServerCertificate=true");
        } catch (SQLException e){
            System.err.println("can not create connection" + e.getMessage());
        }
        System.out.println("  ");
    }// Opretter forbindelse til databasen

    // Metode der tilføjer en trailer. Informationerne omkring traileren der bliver
    // indskrevet kommer an på brugerens indput.
    public void addTrailer(String s0, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8){
        try{
            PreparedStatement ps = con.prepareStatement("INSERT INTO Trailer VALUES(?,?,?,?,?,?,?,?,?,?);");
            ps.setString(1, s0);
            ps.setString(2, s1);
            ps.setInt(3, Integer.parseInt(s2));
            ps.setInt(4, Integer.parseInt(s3));
            ps.setString(5, s4);
            ps.setString(6, s5);
            ps.setString(7, s6);
            ps.setString(8,s7);
            ps.setString(9,s8);

            ps.executeUpdate();
        } catch (SQLException e)
        {
            System.err.println("Kunne ikke tilføje trailer " + e.getMessage());
        }
    }

    //Ændrer på traileren attributter i forhold til brugerens indput
    public void editTrailer(String s0, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, int id){
        try{
            PreparedStatement ps = con.prepareStatement("UPDATE Trailer SET favourite = ?, title = ?, personalRating = ?, IMDBRating = ?, genre = ?, filelink = ?, lastview = ?, posterlink = ?, information = ?  WHERE trailerID = ?;");
            ps.setString(1, s0);
            ps.setString(2, s1);
            ps.setInt(3, Integer.parseInt(s2));
            ps.setInt(4, Integer.parseInt(s3));
            ps.setString(5, s4);
            ps.setString(6, s5);
            ps.setString(7, s6);
            ps.setString(8, s7);
            ps.setString(9, s8);
            ps.setInt(10, id);
            ps.executeUpdate();
        } catch (SQLException e)
        {
            System.err.println("Kunne ikke redgiere trailer" + e.getMessage());
        }
    }

    // Sletter en trailer fra listen af trailers.
    public void deleteTrailer(int id)
    {
        try
        {
            PreparedStatement ps = con.prepareStatement("delete from Trailer where trailerID = ?");
            ps.setInt(1,id);
            ps.executeUpdate();
        }

        catch (SQLException e)
        {
            System.err.println("Kunne ikke slette trialeren" + e.getMessage());
        }
    }

    // Får alle trialers fra starten af, og viser dem i et listview til venstre.
    public List<Trailer> getAllTrailers()
    {
        List<Trailer> getAllTrailers = new ArrayList<>();
        try
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Trailer");
            ResultSet rs = ps.executeQuery();

            Trailer traileren;
            while(rs.next())
            {
                int id = rs.getInt(1);
                String favourite = rs.getString(2);
                String title = rs.getString(3);
                int personalRating = rs.getInt(4);
                int IMDBRating = rs.getInt(5);
                String genre = rs.getString(6);
                String filelink = rs.getString(7);
                String lastview = rs.getString(8);
                String posterlink = rs.getString(9);
                String information = rs.getString(10);

                traileren = new Trailer(id, favourite, title, personalRating, IMDBRating, genre, filelink, lastview, posterlink, information);
                getAllTrailers.add(traileren);
            }
        }

        catch (SQLException e)
        {
            System.err.println("can not access records" + e.getMessage());
        }
        return getAllTrailers;
    }

    // Metode der søger efter trailers i listen over trailers.
    // Man kan søge efter trailers, genre, og IMDBRating.
    public List<Trailer> getSearchedTrailer(String query)
    {
        List<Trailer> searchedTrailer= new LinkedList<>();
        try
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Trailer WHERE title LIKE ? OR genre LIKE ? OR IMDBRating LIKE ?;");
            ps.setString(1, query);
            ps.setString(2, query);
            ps.setString(3, query);
            ResultSet rs = ps.executeQuery();

            Trailer trailer;
            while(rs.next())
            {
                int id = rs.getInt(1);
                String favourite = rs.getString(2);
                String title = rs.getString(3);
                int personalRating = rs.getInt(4);
                int IMDBRating = rs.getInt(5);
                String genre = rs.getString(6);
                String filelink = rs.getString(7);
                String lastview = rs.getString(8);
                String posterlink = rs.getString(9);
                String information = rs.getString(10);

                trailer = new Trailer(id, favourite, title, personalRating, IMDBRating, genre, filelink, lastview, posterlink, information);
                searchedTrailer.add(trailer);
            }
        }

        catch (SQLException e)
        {
            System.err.println("Kunne ikke finde traileren, " + e.getMessage());
        }
        return searchedTrailer;
    }

}