package com.example.filmprojekt;

import com.example.filmprojekt.Model.*;
import com.example.filmprojekt.dao.GenrerDAO;
import com.example.filmprojekt.dao.PromosDAO;
import com.example.filmprojekt.dao.TrailerDAO;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.Slider;
import javafx.scene.control.Button;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class FilmController
{

    private int searchCounter = 0;

    @FXML
    private TextArea information;
    @FXML
    private Button deleteGenreButton;
    @FXML
    private Button deleteGrTrailer;
    @FXML
    private Button editGenre;
    @FXML
    private ListView genreList;
    @FXML
    private TableView<Trailer> GrTrailersTable;
    @FXML
    private TableColumn<Trailer, String> tableFavourite;
    @FXML
    private  TableColumn<Trailer, String> tableTitle;
    @FXML
    private TableColumn<Trailer, String> tablePersonal;
    @FXML
    private  TableColumn<Trailer, String> tableIMDB;
    @FXML
    private  TableColumn<Trailer, String> tableGenre;
    @FXML
    private TableColumn<Trailer, String> tableLastview;

    private final ObservableList<Trailer> trailersInGenreObsList = FXCollections.observableArrayList();

    @FXML
    private Label genreName, quantityOfTrailers;
    @FXML
    private Button newGenre;
    @FXML
    private ImageView poster;
    @FXML
    private TextField searchBar;
    @FXML
    private ImageView sogImg;
    @FXML
    private BorderPane storPane;
    @FXML
    private Image sog, noSog;
    @FXML
    private ListView trailerList;

    public void initialize() {
        showGenre();
        showTrailers();
        showPromos();
        setImage();

        GrTrailersTable.getSelectionModel().select(0);

     tableFavourite.setCellValueFactory(new PropertyValueFactory<Trailer, String>("favourite"));
     tableTitle.setCellValueFactory(new PropertyValueFactory<Trailer, String>("title"));
     tablePersonal.setCellValueFactory(new PropertyValueFactory<Trailer, String>("personalRating"));
     tableIMDB.setCellValueFactory(new PropertyValueFactory<Trailer, String>("IMDBRating"));
     tableGenre.setCellValueFactory(new PropertyValueFactory<Trailer, String>("genre"));
     tableLastview.setCellValueFactory(new PropertyValueFactory<Trailer, String>("lastview"));



    }

    public void showTrailers() {
        List<Trailer> traileren = tdi.getAllTrailers();
        for (Object trailer : traileren)
        {
            trailerList.getItems().add(trailer);
        }
    } //Viser alle Trailers i et listview

    public void showGenre() {
        List<Genrer> genre1 = gdi.getAllGenres();
        for (Genrer genren : genre1)
        {
            genreList.getItems().add(genren);
        }
    } //Viser alle Genre i et listview

    public void showPromos() {
        Genrer gr = (Genrer) genreList.getItems().get(0);
        List<Trailer> promo = pdi.getGenreTrailers(gr);
        genreName.setText(gr.getListName());
        for (Trailer movie : promo)
        {
            GrTrailersTable.getItems().add(movie);
            quantityOfTrailers.setText(String.valueOf(promo.size()));
        }
    } //Viser alle trailers i en valgt Genre

    public void setImage() {
        sogImg.setImage(sog);
    } //Sætter de billeder der skal være som kan ændres

    @FXML
    void addGenreButton(ActionEvent event) {
        Dialog<ButtonType> grdialog = new Dialog();

        // Her sættes et nyt vindue op til oprettelse af en genre
        grdialog.setTitle("Create Genre");
        grdialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField grName = new TextField();
        grName.setPromptText("Name Genre...");
        VBox opsæt = new VBox(grName);
        grdialog.getDialogPane().setContent(opsæt);

        // Her afsluttes dialogen med at man kan trykke på OK
        Optional<ButtonType> knap = grdialog.showAndWait();

        // Derefter kan jeg hente felternes indhold ud og sætte de rigtige informationer ind
        if (knap.get() == ButtonType.OK)
            try {
                gdi.addGenre(grName.getText());

                List<Genrer> genrer1 = gdi.getAllGenres();
                genreList.getItems().clear();
                for (Genrer genrer : genrer1) {
                    genreList.getItems().add(genrer);
                }
            }

            //Laver en catch til hvis genren ikke kan oprettes
            catch (Exception e)
            {
                System.err.println("Fejl: " + e.getMessage());
            }
    } //Opretter en ny genre som sættes ind i mit anden sidste listview til venstre

    @FXML
    void editGenreButton (ActionEvent event){

        Dialog<ButtonType> grEditDialog = new Dialog();

        // Her sættes et nyt vindue op
        grEditDialog.setTitle("Edit Genre");
        grEditDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        TextField grName = new TextField();
        grName.setPromptText("Name Genre...");
        VBox opsæt = new VBox(grName);
        grEditDialog.getDialogPane().setContent(opsæt);

        Optional<ButtonType> knap = grEditDialog.showAndWait();

        // Derefter kan man hente felternes indhold ud og gøre hvad der skal gøres...
        if (knap.get() == ButtonType.OK)
            try {
                ObservableList valgteIndeks = genreList.getSelectionModel().getSelectedIndices();
                if (valgteIndeks.size() == 0)
                    System.out.println("Choose a Genre");
                else
                    for (Object indeks : valgteIndeks) {
                        System.out.println("Clicked on " + genreList.getSelectionModel().getSelectedItem());
                        Genrer gr = (Genrer) genreList.getItems().get((int) indeks);
                        gdi.updateGenre(grName.getText(),gr.getId());
                        genreList.getItems().clear();
                        showGenre();
                    }

                //Laver en catch til hvis genren ikke kan skifte navn
            } catch (Exception e) {
                System.err.println("Something went wrong");
                System.err.println("Fejl: " + e.getMessage());
            }
    } //Ændrer navnet på en genre

    @FXML
    void deleteGenreButton(ActionEvent event) {
        Dialog<ButtonType> dialog = new Dialog();

        // Her sættes et nyt vindue op
        dialog.setTitle("Delete genre");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Label infoLabel = new Label("Are you sure you want to continue?");

        dialog.getDialogPane().setContent(infoLabel);

        // Her afsluttes dialogen med at man kan trykke på OK
        Optional<ButtonType> knap = dialog.showAndWait();
        // Derefter kan man hente informationer der skal bruges
        if (knap.get() == ButtonType.OK)
            try {
                ObservableList valgteIndeks = genreList.getSelectionModel().getSelectedIndices();
                if (valgteIndeks.size() == 0)
                    System.out.println("Choose genre");
                else
                    for (Object indeks : valgteIndeks)
                    {
                        System.out.println("Clicked on " + genreList.getSelectionModel().getSelectedItem());
                        Genrer gr = (Genrer) genreList.getItems().get((int) indeks);
                        gdi.deleteGr(gr.getId());
                        genreList.getItems().clear();
                        showGenre();
                    }
                //Laver en catch til hvis genren ikke kunne fjernes
            } catch (Exception e) {
                System.err.println("Something went wrong");
                System.err.println("Error: " + e.getMessage());
            }
    } //Fjerner en genre

    @FXML
    void addTrailerButton(ActionEvent event) throws IOException {
        Dialog<ButtonType> trailerDialog = new Dialog();

        // Her sættes vinduet op
        trailerDialog.setTitle("New Trailer");
        trailerDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        //Hbox m favorit
        Label favouriteLabel = new Label("Favourite:");
        TextField favouriteText = new TextField();
        favouriteText.setEditable(false);
        Button favouriteButton = new Button("F");
        favouriteButton.setId("favoritKnap");
        Button notFavouriteButton = new Button("N");

        favouriteButton.setOnAction(e -> favouriteText.setText("F"));
        notFavouriteButton.setOnAction(e -> favouriteText.clear());


        HBox favouriteH = new HBox(favouriteLabel, favouriteText, favouriteButton, notFavouriteButton);
        favouriteH.setSpacing(2);

        //HBox m titel
        Label titleLabel = new Label("Title:");
        TextField titleText = new TextField();
        titleText.setPromptText("Title...");
        HBox titleH = new HBox(titleLabel, titleText);
        titleH.setSpacing(8);

        //HBox m Personlig Bedømmelse
        Label personalRatingLabel = new Label("Personal rating:");
        TextField personalRatingText = new TextField();
        personalRatingText.setPromptText("Personal rating...");
        HBox personalRatingH = new HBox(personalRatingLabel, personalRatingText);
        personalRatingH.setSpacing(8);

        //HBox m IMDB Bedømmelse
        Label IMDBRatingLabel = new Label("IMDB rating");
        TextField IMDBRatingText = new TextField();
        IMDBRatingText.setPromptText("IMDB rating...");
        HBox IMDBRatingH = new HBox(IMDBRatingLabel, IMDBRatingText);
        IMDBRatingH.setSpacing (8);

        //HBox m Genre
        Label genreLabel = new Label("Genre");
        TextField genreText = new TextField();
        genreText.setPromptText("Genre...");
        HBox genreH = new HBox(genreLabel, genreText);
        genreH.setSpacing(8);

        //HBox m fil
        Label fileLabel = new Label("File:");
        TextField fileText = new TextField();
        fileText.setEditable(false);
        fileText.setPromptText("File.mp4 , .mp4...");

        Button fileButton = new Button("Choose...");
        fileButton.setId("filKnap");

        final FileChooser fileChooser = new FileChooser();
        new FileChooser.ExtensionFilter("Mp4 files", "mp4");
        fileButton.setOnAction(e -> {
            try
            {
                Stage stage = (Stage) storPane.getScene().getWindow();
                File file = fileChooser.showOpenDialog(stage);
                System.out.println("Valgt filnavn: " + file.getName());
                System.out.println("Filechoossserens path: " +file.getPath());
                fileText.setText(file.getName());
                file.renameTo(new File("file:///C:/Users/thewi/Desktop/FilmProjekt/src/main/resources/com/example/filmprojekt/" + file.getName()));
            }

            //Laver en catch til hvis der ikke kunne findes en fil
            catch (Exception ex)
            {
                System.err.println("Vælg fil " + ex.getMessage());
            }
        });
        HBox fileH = new HBox(fileLabel, fileText, fileButton);
        fileH.setSpacing(8);

        //HBox m lastview
        Label lastviewLabel = new Label("Lastview");
        TextField lastviewText = new TextField();
        lastviewText.setPromptText("Lastview...");
        HBox lastviewH = new HBox(lastviewLabel, lastviewText);
        lastviewH.setSpacing(8);

        //HBox m poster
        Label posterLabel = new Label("Poster:");
        TextField posterText = new TextField();
        posterText.setEditable(false);
        posterText.setPromptText("File.jpeg , .jpeg...");

        Button posterButton = new Button("Choose...");
        posterButton.setId("posterKnap");

        final FileChooser posterChooser = new FileChooser();
        new FileChooser.ExtensionFilter("jpeg files", "jpeg");
        posterButton.setOnAction(e -> {
            try
            {
                Stage stage = (Stage) storPane.getScene().getWindow();
                File poster = posterChooser.showOpenDialog(stage);
                System.out.println("Valgt filnavn: " + poster.getName());
                System.out.println("Filechoossserens path: " + poster.getPath());
                posterText.setText(poster.getName());
                poster.renameTo(new File("C:/thewi/Desktop/FilmProjekt/src/main/resources/com/example/filmprojekt/" + poster.getName()));
            }

            //Laver en catch til hvis der ikke kunne findes en fil
            catch (Exception ex)
            {
                System.err.println("Vælg fil " + ex.getMessage());
            }
        });
        HBox posterH = new HBox(posterLabel, posterText, posterButton);
        posterH.setSpacing(8);

        //HBox m information
        Label informationLabel = new Label("Information");
        TextField informationText = new TextField();
        informationText.setPromptText("Information...");
        HBox informationH = new HBox(informationLabel, informationText);
        informationH.setSpacing(8);

        //VBox med opsæt
        VBox opsæt = new VBox(favouriteH, titleH, personalRatingH, IMDBRatingH, genreH, fileH, lastviewH, posterH, informationH);
        opsæt.setSpacing(16);
        trailerDialog.getDialogPane().setContent(opsæt);

        // Her afsluttes dialogen med at man kan trykke på OK
        Optional<ButtonType> knap = trailerDialog.showAndWait();
        // Derefter kan vi hente informationer ind til genren
        if (knap.get() == ButtonType.OK)
            try
            {
                tdi.addTrailer(favouriteText.getText(), titleText.getText(), personalRatingText.getText(), IMDBRatingText.getText(), genreText.getText(), fileText.getText(), lastviewText.getText(), posterText.getText(), informationText.getText());

                List<Trailer> trailer = tdi.getAllTrailers();
                trailerList.getItems().clear();
                for (Trailer trailers : trailer){
                    trailerList.getItems().add(trailers);
                }
                trailerList.scrollTo(trailerList.getItems().size());
            }

            //Laver en catch til hvis
            catch (Exception e)
            {
                System.err.println("Fejl: " + e.getMessage());
            }
    } // Tilføjer trailer til listen med trailers

    @FXML
    void editTrailerButton(ActionEvent event){
    Dialog<ButtonType> trailerDialog = new Dialog();
    ObservableList chosenTrailer = trailerList.getSelectionModel().getSelectedIndices();

        for (Object indeks : chosenTrailer) {
            System.out.println("Clicked on " + trailerList.getSelectionModel().getSelectedItem());
            Trailer t = (Trailer) trailerList.getItems().get((int) indeks);

            // Her sættes vinduet op
            trailerDialog.setTitle("Edit Trailer");
            trailerDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            //HBox m favourite
            Label favouriteLabel = new Label("Favourite:");
            TextField favouriteText = new TextField();
            favouriteText.setEditable(false);
            Button favouriteButton = new Button("F");
            favouriteButton.setId("favoritKnap");
            Button notFavouriteButton = new Button("N");

            favouriteButton.setOnAction(e -> favouriteText.setText("F"));

            notFavouriteButton.setOnAction(e -> favouriteText.clear());

            HBox favouriteH = new HBox(favouriteLabel, favouriteText, favouriteButton, notFavouriteButton);
            favouriteH.setSpacing(8);

            //HBox m titel
            Label titleLabel = new Label("Title:");
            TextField titleText = new TextField();
            titleText.setText(t.getTitle());
            HBox titleH = new HBox(titleLabel, titleText);
            titleH.setSpacing(8);

            //HBox m personalRating
            Label personalRatingLabel = new Label("Personal rating:");
            TextField personalRatingText = new TextField();
            personalRatingText.setText(String.valueOf(t.getPersonalRating()));
            HBox personalRatingH = new HBox(personalRatingLabel, personalRatingText);
            personalRatingH.setSpacing(8);

            //Hbox m IMDBRating
            Label IMDBRatingLabel = new Label("IMDB rating:");
            TextField IMDBRatingText = new TextField();
            IMDBRatingText.setText(String.valueOf(t.getIMDBRating()));
            HBox IMDBRatingH = new HBox(IMDBRatingLabel, IMDBRatingText);
            IMDBRatingH.setSpacing(8);

            //Hbox m genre
            Label genreLabel = new Label("Genre:");
            TextField genreText = new TextField();
            genreText.setText(t.getGenre());
            HBox genreH = new HBox(genreLabel, genreText);
            genreH.setSpacing(8);

            //HBox m fil
            Label fileLabel = new Label("File:");
            TextField fileText = new TextField();
            fileText.setText(t.getFilelink());
            fileText.setPromptText("File.mp4 , .mp4...");
            Button fileButton = new Button("Choose...");
            fileButton.setId("filKnap");
            final FileChooser fileChooser = new FileChooser();
            new FileChooser.ExtensionFilter("Mp4 files", "mp4");
            fileButton.setOnAction(e -> {
                try
                {
                    Stage stage = (Stage) storPane.getScene().getWindow();
                    File file = fileChooser.showOpenDialog(stage);
                    System.out.println("Valgt filnavn: " + file.getName());
                    System.out.println("Filechoossserens path: " +file.getPath());
                    fileText.setText(file.getName());
                    file.renameTo(new File("file:///C:/Users/thewi/Desktop/FilmProjekt/src/main/resources/com/example/filmprojekt/" + file.getName()));
                }

                //Laver en catch til hvis trailerens fil ikke kunne findes
                catch (Exception ex) {
                    System.err.println("Vælg fil " + ex.getMessage());
                }

            });
            HBox fileH = new HBox(fileLabel, fileText, fileButton);
            fileH.setSpacing(8);

            //HBox m lastview
            Label lastviewLabel = new Label("Lastview");
            TextField lastviewText = new TextField();
            lastviewText.setText(t.getLastview());
            HBox lastviewH = new HBox(lastviewLabel, lastviewText);
            lastviewH.setSpacing(8);

            //HBox m poster
            Label posterLabel = new Label("Poster:");
            TextField posterText = new TextField();
            posterText.setPromptText("File.jpeg , .jpeg...");
            Button posterButton = new Button("Choose...");
            posterButton.setId("posterKnap");
            final FileChooser posterChooser = new FileChooser();
            new FileChooser.ExtensionFilter("jpeg files", "jpeg");
            fileButton.setOnAction(e -> {
                try
                {
                    Stage stage = (Stage) storPane.getScene().getWindow();
                    File poster = posterChooser.showOpenDialog(stage);
                    System.out.println("Valgt filnavn: " + poster.getName());
                    System.out.println("Filechoossserens path: " + poster.getPath());
                    posterText.setText(poster.getName());
                    poster.renameTo(new File("file:///C:/Users/thewi/Desktop/FilmProjekt/src/main/resources/com/example/filmprojekt/" + poster.getName()));
                }

                //Laver en catch til hvis trailerens poster ikke kunne findes
                catch (Exception ex) {
                    System.err.println("Vælg fil " + ex.getMessage());
                }

            });
            HBox posterH = new HBox(posterLabel, posterText, posterButton);
            posterH.setSpacing(8);

            //HBox m information
            Label informationLabel = new Label("Information");
            TextField informationText = new TextField();
            informationText.setText(t.getInformation());
            HBox informationH = new HBox(informationLabel, informationText);
            informationH.setSpacing(8);

            //VBox med opsæt
            VBox opsæt = new VBox(favouriteH, titleH, personalRatingH, IMDBRatingH, genreH, fileH, lastviewH, posterH, informationH);
            opsæt.setSpacing(16);
            trailerDialog.getDialogPane().setContent(opsæt);

            // Her afsluttes dialogen med at man kan trykke på OK
            Optional<ButtonType> knap = trailerDialog.showAndWait();
            // Derefter kan vi henter felternes indhold ud og gøre hvad der skal gøres...
            if (knap.get() == ButtonType.OK)
            {
                try {
                    tdi.editTrailer(favouriteText.getText(), titleText.getText(), personalRatingText.getText(), IMDBRatingText.getText(), genreText.getText(), fileText.getText(), lastviewText.getText(), posterText.getText(), informationText.getText(), t.getId());
                    List<Trailer> trailer = tdi.getAllTrailers();
                    trailerList.getItems().clear();
                    for (Trailer trailers : trailer) {
                        trailerList.getItems().add(trailers);
                    }
                }

                //Laver en catch til hvis traileren ikke kunne redigeres
                catch (Exception e) {
                    System.err.println("Fejl: " + e.getMessage());
                }
            }
        }
    } //Ændrer ønskede attributter ved den valgte trailer

    @FXML
    void deleteTrailerButton(ActionEvent event) {
        Dialog<ButtonType> dialog = new Dialog();

        // Her sættes vinduet op
        dialog.setTitle("Delete trailer");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Label infoLabel = new Label("Are you sure you want to continue?");

        dialog.getDialogPane().setContent(infoLabel);

        // Her afsluttes dialogen med at man kan trykke på OK
        Optional<ButtonType> knap = dialog.showAndWait();
        // Derefter kan man henter felternes indhold ud og gøre hvad der skal gøres...

        if (knap.get() == ButtonType.OK)
            try
            {
                ObservableList valgteIndeks = trailerList.getSelectionModel().getSelectedIndices();
                if (valgteIndeks.size() == 0)
                    System.out.println("Choose a trailer");
                else
                    for (Object indeks : valgteIndeks)
                    {
                        System.out.println("Clicked on " + trailerList.getSelectionModel().getSelectedItem());
                        Trailer t  = (Trailer) trailerList.getItems().get((int) indeks);
                        tdi.deleteTrailer(t.getId());
                        trailerList.getItems().clear();
                        showTrailers();
                    }
            }
            //Laver en catch til hvis traileren ikke kunne slettes
            catch (Exception e)
            {
                System.err.println("Something went wrong");
                System.err.println(e.getMessage());
            }
    } // Sletter en valgt trailer fra trailerlisten

    @FXML
    void deleteGrTrailer(ActionEvent e)
    {
        // pdi.deleteGrTrailer her - husk observarblelist og objekt

        ObservableList valgteIndeks = GrTrailersTable.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Vælg en trailer");
        else
            for (Object indeks : valgteIndeks) {
                System.out.println("Der blev klikket på " + GrTrailersTable.getSelectionModel().getSelectedItem());
                Trailer t = (Trailer) GrTrailersTable.getItems().get((int) indeks);
                pdi.deleteGrTrailer(t.getId());
            }

        ObservableList valgteGr = genreList.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Vælg en genre");
        else
            for (Object indeks : valgteGr)
            {
                GrTrailersTable.getItems().clear();
                Genrer gr = (Genrer) genreList.getItems().get((int) indeks);
                List<Trailer> trailer = pdi.getGenreTrailers(gr);
                for (Trailer trail : trailer)
                {
                    GrTrailersTable.getItems().add(trail);
                    GrTrailersTable.getSelectionModel().select(0);
                }
            }
    } //Sletter trailer fra genremappe


    @FXML
    void addTrailerToFolderButton(ActionEvent e) {
        // Opfanger at man har valgt en trailer fra listen med trailers
        ObservableList valgteIndeks = trailerList.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Choose a trailer");
        else
            for (Object indeks : valgteIndeks)
            {
                System.out.println("Clicked on " + trailerList.getSelectionModel().getSelectedItem());
                Trailer t  = (Trailer) trailerList.getItems().get((int) indeks);
                Genrer gr = (Genrer) genreList.getSelectionModel().getSelectedItem();
                pdi.addTheTrailer(gr.getId(),t.getId());

                GrTrailersTable.getItems().clear();
                List<Trailer> Promos = pdi.getGenreTrailers(gr);
                for (Trailer trailer : Promos)
                {
                    // Tilføjer traileren til genren og ændrer på quantityOfTrailers labelen
                    GrTrailersTable.getItems().add(trailer);
                    quantityOfTrailers.setText(String.valueOf(Promos.size()));
                }
            }
    } // Funktion der tilføjer en eksisterende trailer til en eksisterende genremappe

    @FXML
    void playTrailerButton(ActionEvent event) {
        //Starter en ny scene til at afspille en trailer
        Stage stage = (Stage) storPane.getScene().getWindow();
            stage.setTitle("Movie Player");
            Group root = new Group();
            Media trailer = new Media(String.valueOf(getClass().getResource(getFileFromSelected())));
            final MediaPlayer player = new MediaPlayer(trailer);
            MediaView view = new MediaView(player);

            System.out.println("media.width: "+trailer.getWidth());

            //Laver en timeline til at tjekke hvor lang en trailer er
            final Timeline slideIn = new Timeline();
            final Timeline slideOut = new Timeline();
            root.setOnMouseExited(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    slideOut.play();
                }
            });
            root.setOnMouseEntered(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    slideIn.play();
                }
            });
            //Laver en slider til at kunne styre hvor i traileren man vil hen
            final VBox durationBox = new VBox();
            final Slider slider = new Slider();
            durationBox.getChildren().add(slider);

            final HBox hbox = new HBox(2);

            durationBox.getChildren().add(hbox);

            root.getChildren().add(view);
            root.getChildren().add(durationBox);

            Scene scene = new Scene(root, 400, 400, Color.BLACK);
            stage.setScene(scene);
            stage.show();

            //Afspiller selve traileren
            player.play();
            player.setOnReady(new Runnable() {
                @Override
                public void run() {
                    int w = player.getMedia().getWidth();
                    int h = player.getMedia().getHeight();

                    stage.setMinWidth(w);
                    stage.setMinHeight(h);

                    durationBox.setMinSize(w, 200);
                    durationBox.setTranslateY(h - 200);

                    slider.setMin(0.0);
                    slider.setValue(0.0);
                    slider.setMax(player.getTotalDuration().toSeconds());

                    slideOut.getKeyFrames().addAll(
                            new KeyFrame(new Duration(0),
                                    new KeyValue(durationBox.translateYProperty(), h-100),
                                    new KeyValue(durationBox.opacityProperty(), 0.9)
                            ),
                            new KeyFrame(new Duration(300),
                                    new KeyValue(durationBox.translateYProperty(), h),
                                    new KeyValue(durationBox.opacityProperty(), 0.0)
                            )
                    );
                    slideIn.getKeyFrames().addAll(
                            new KeyFrame(new Duration(0),
                                    new KeyValue(durationBox.translateYProperty(), h),
                                    new KeyValue(durationBox.opacityProperty(), 0.0)
                            ),
                            new KeyFrame(new Duration(300),
                                    new KeyValue(durationBox.translateYProperty(), h-100),
                                    new KeyValue(durationBox.opacityProperty(), 0.9)
                            )
                    );
                }
            });
            //Laver en listener til at til at slideren ved hvor langt i traileren man er
            player.currentTimeProperty().addListener(new ChangeListener<Duration>() {
                @Override
                public void changed(ObservableValue<? extends Duration> observableValue, Duration duration, Duration current) {
                    slider.setValue(current.toSeconds());
                }
            });
            //Gør det muligt og gå længere hen eller tilbage i en trailer ved at hive i slider knappen
            slider.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    player.seek(Duration.seconds(slider.getValue()));
                }
            });

        } // Spiller den valgte trailer

    @FXML
    void searchButton(ActionEvent event) {
        if (searchCounter == 0){
            sogImg.setImage(noSog);
            List<Trailer> searchTrailer = tdi.getSearchedTrailer(searchBar.getText());
            trailerList.getItems().clear();
            for(Trailer trailer: searchTrailer)
            {
                trailerList.getItems().add(trailer);
            }
            searchCounter = 1;
        } else if (searchCounter == 1) {
            sogImg.setImage(sog);
            searchBar.setText("");
            trailerList.getItems().clear();
            showTrailers();
            searchCounter = 0;
        }
    } // Søger efter trailer i ListViewet med trailers

    @FXML
    void genreClick(MouseEvent event) {
        ObservableList valgteIndeks = genreList.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Choose a genre");
        else
            for (Object indeks : valgteIndeks)
            {
                GrTrailersTable.getItems().clear();
                System.out.println("Clicked on " + genreList.getSelectionModel().getSelectedItem());
                Genrer gr = (Genrer) genreList.getItems().get((int) indeks);
                genreName.setText(gr.getListName());
                quantityOfTrailers.setText("0");
                List<Trailer> trailers = pdi.getGenreTrailers(gr);
                for (Trailer Promos : trailers)
                {
                    GrTrailersTable.getItems().add(Promos);
                    quantityOfTrailers.setText(String.valueOf(trailers.size()));
                }
            }
    } // Får den valgte genremappe i listen med genre

    @FXML
    void trailerClick(MouseEvent event) {
        ObservableList valgteIndeks = trailerList.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Choose a trailer");
        else
            for (Object indeks : valgteIndeks)
            {
                System.out.println("Clicked on " + trailerList.getSelectionModel().getSelectedItem());
            }
    } // Får den valgte trailer i listen med trailers

    @FXML
    void GrTrailerClick(MouseEvent e) {ObservableList valgteIndeks = GrTrailersTable.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Vælg en trailer");
        else
            for (Object indeks : valgteIndeks)
            {
                System.out.println("Der blev klikket på " + GrTrailersTable.getSelectionModel().getSelectedItem());
                tableFavourite.setCellValueFactory(new PropertyValueFactory<>("Favourite"));
                tableTitle.setCellValueFactory(new PropertyValueFactory<>("Title"));
                tablePersonal.setCellValueFactory(new PropertyValueFactory<>("Personal Rating"));
                tableIMDB.setCellValueFactory(new PropertyValueFactory<>("IMDB Rating"));
                tableGenre.setCellValueFactory(new PropertyValueFactory<>("Genre"));

                Trailer t  = (Trailer) GrTrailersTable.getItems().get((int) indeks);
                information.setText(t.getInformation());
                //poster.setImage(t.getPosterlink());
            }

    }//Fik sat beskrivelse på en trailer, men kan ikke få poster ind
    public String getFileFromSelected(){
        ObservableList valgteIndeks = GrTrailersTable.getSelectionModel().getSelectedIndices();
        if (valgteIndeks.size() == 0)
            System.out.println("Choose a trailer");
        else
            for (Object indeks : valgteIndeks)
            {
                Trailer t = (Trailer) GrTrailersTable.getItems().get((int) indeks);
                return t.getFilelink();
            }
        return null;
    } //Finder filnavnet på traileren der er valgt i listen

    GenrerDAO gdi = new GenrerDAOImpl();
    PromosDAO pdi = new PromosDAOImpl();
    TrailerDAO tdi = new TrailerDAOImpl();

}