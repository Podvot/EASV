package com.example.filmprojekt.dao;

import com.example.filmprojekt.Model.Genrer;

import java.util.List;

public interface GenrerDAO
{
    public void addGenre(String genre); // Create genre

    public List<Genrer> getAllGenres();

    public void deleteGr(int gr); // Delete genre

    public void updateGenre(String genre, int gr);
}
