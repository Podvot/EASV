package com.example.filmprojekt.dao;

import com.example.filmprojekt.Model.Genrer;
import com.example.filmprojekt.Model.Trailer;

import java.util.List;

public interface PromosDAO
{

    public List<Trailer> getGenreTrailers(Genrer glist); // Get all promos

    public void deleteGrTrailer(int tl); // Delete promo

    public void addTheTrailer(int id1, int id2); // Add trailer to folder

}
