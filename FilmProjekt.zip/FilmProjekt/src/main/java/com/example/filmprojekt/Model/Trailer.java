package com.example.filmprojekt.Model;

public class Trailer {
    private int id;
    private String favourite;
    private String title;
    private String personalRating;
    private String IMDBRating;
    private String genre;
    private String filelink;
    private String lastview;
    private String posterlink;
    private String information;

    // Der blvier automatisk sat trailerID på en nyskabt trailer

    public Trailer(int id, String favourite, String title, int personalRating, int IMDBRating, String genre, String filelink, String lastview, String posterlink, String information)
    {
        this.id = id;
        this.favourite = favourite;
        this.title = title;
        this.personalRating = String.valueOf(personalRating);
        this.IMDBRating = String.valueOf(IMDBRating);
        this.genre = genre;
        this.filelink = filelink;
        this.lastview = lastview;
        this.posterlink = posterlink;
        this.information = information;
    }

    public String toString()
    {
        return favourite + ", " + title + ", " + personalRating + ", " + IMDBRating + ", " + genre + ", " + lastview + ", " + information;
    }

    // Nedenstående er alle gettere


    public int getId() {
        return id;
    }

    public String getFavourite() {
        return favourite;
    }

    public String getTitle() {
        return title;
    }

    public String getPersonalRating() {
        return personalRating;
    }

    public String getIMDBRating() {
        return IMDBRating;
    }

    public String getGenre() {
        return genre;
    }

    public String getFilelink() {
        return filelink;
    }

    public String getLastview() {
        return lastview;
    }


    public String getPosterlink() {
        return posterlink;
    }

    public String getInformation() {
        return information;
    }

}

